from helpers import borrarPantalla, gotoxy
import time
class Menu:
    def __init__(self,titulo="",opciones=[],col=6,fil=1):
        self.titulo=titulo
        self.opciones=opciones
        self.col=col
        self.fil=fil
        
    def menu(self):
        gotoxy(self.col,self.fil);print(self.titulo)
        self.col-=5
        for opcion in self.opciones:
            self.fil +=1
            gotoxy(self.col,self.fil);print(opcion)
        gotoxy(self.col+5,self.fil+2)
        opc = input("Elija opcion[1...{}]:".format(len(self.opciones))) 
        return opc   

class Valida:
    def solo_numeros(self,mensajeError,col,fil):
        while True: 
            gotoxy(col,fil)            
            valor = input()
            try:
                if int(valor) > 0:
                    break
            except:
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*25)
        return valor

    def solo_letras(self,mensaje,mensajeError,col,fil): 
        while True:
            gotoxy(col,fil)
            valor = str(input("{}".format(mensaje)))
            if valor.isalpha():
                break
            else:
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*25)
        return valor

    def solo_decimales(self,mensajeError,col,fil):
        while True:
            gotoxy(col,fil)            
            valor = input()
            try:
                valor = float(valor)
                if valor > float(0):
                    break
            except:
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*25)
        return valor
    
    def cedula(self,mensajeError,col,fil):
        while True:
            gotoxy(col,fil)            
            valor = input()
            cedu=int(valor)
            if len(valor) == 10 and type(cedu) == int:
                break
            else:    
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*30)
        return valor

    def solo_dia(self,mensajeError,col,fil):
        while True: 
            gotoxy(col,fil)            
            valor = input()
            if 0< int(valor) <=31:
                break
            else:
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*25)
        return int(valor)

    def solo_mes(self,mensajeError,col,fil):
        while True: 
            gotoxy(col,fil)            
            valor = input()
            if int(valor)<=12:
                    break
            else:
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*25)
        return int(valor)
    
    def solo_año(self,mensajeError,col,fil):
        while True: 
            gotoxy(col,fil)            
            valor = input()
            if int(valor) > 0:
                break
            else:    
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*25)
        return int(valor)

    def grabar(self,mensajeError,col,fil): 
        while True:
            gotoxy(col,fil)
            valor = str(input()).lower()
            if valor  == "s" or valor == "n":
                break
            else:
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*25)
        return valor

    def rol(sel,mensajeError,col,fil):
        while True:
            gotoxy(col,fil)
            valor = str(input()).upper()
            if valor == "O" or valor == "A":
                break
            else:
                gotoxy(col,fil);print(mensajeError)
                time.sleep(1)
                gotoxy(col,fil);print(" "*25)
        return valor                